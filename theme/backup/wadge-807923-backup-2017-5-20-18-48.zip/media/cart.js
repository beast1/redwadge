var btnRemoveFromBasket = $("js-basket__remove-btn");

//btnRemoveFromBasket
//  .click(function() {
//    if () {
//      $(".page-main").replaceWith(".alert");
//    }
//});